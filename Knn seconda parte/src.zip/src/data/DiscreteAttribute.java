package data;
public class DiscreteAttribute extends Attribute {
    DiscreteAttribute(String name, int index) {
        super(name, index);
    }
}