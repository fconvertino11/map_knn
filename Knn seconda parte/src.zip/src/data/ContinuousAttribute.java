package data;
public class ContinuousAttribute extends Attribute {
    ContinuousAttribute(String name, int index) {
        super(name, index);
    }
}