# KNNMiner
The k-nearest neighbors (translatable as first k-neighbors), abbreviated to K-NN, is a pattern recognition algorithm for classifying objects based on the characteristics of objects close to the one considered. In both cases, the input is the closest k training examples in the feature space. The output depends on whether k-NN is used for classification or regression
